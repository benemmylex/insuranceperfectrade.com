<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['error_prefix'] = '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times</button><i class="fa fa-times"></i> ';
$config['error_suffix'] = '</div>';
?>